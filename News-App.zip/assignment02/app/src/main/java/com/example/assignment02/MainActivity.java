package com.example.assignment02;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Spinner spRegion, spCategory;
    Button btSubmit;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btSubmit = (Button) findViewById(R.id.am_btSubmit);
        spRegion = (Spinner) findViewById(R.id.am_spRegion);
        spCategory = (Spinner) findViewById(R.id.am_spCategory);

        ArrayAdapter<CharSequence> adRegion = ArrayAdapter.createFromResource(this, R.array.regions, android.R.layout.simple_spinner_item);
        adRegion.setDropDownViewResource(android.R.layout.simple_spinner_item);
        spRegion.setAdapter(adRegion);

        ArrayAdapter<CharSequence> adTopic = ArrayAdapter.createFromResource(this, R.array.categories, android.R.layout.simple_spinner_item);
        adTopic.setDropDownViewResource(android.R.layout.simple_spinner_item);
        spCategory.setAdapter(adTopic);

        btSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Toast.makeText(MainActivity.this,spRegion.getSelectedItem().toString() + " --- " + spTopic.getSelectedItem().toString(), Toast.LENGTH_SHORT).show();
                Intent i = new Intent(MainActivity.this, NewsHeadlinesActivity.class);
                i.putExtra("country", spRegion.getSelectedItem().toString());
                i.putExtra("category", spCategory.getSelectedItem().toString());
                startActivity(i);
            }
        });
    }

}