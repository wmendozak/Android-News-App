package com.example.assignment02;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

public class CustomViewHolder extends RecyclerView.ViewHolder {
    TextView tvTitle, tvSource;
    ImageView ivHeadline;
    CardView cvMain;
    public CustomViewHolder(@NonNull View itemView) {
        super(itemView);
        tvTitle = itemView.findViewById(R.id.hli_tvTitle);
        tvSource = itemView.findViewById(R.id.hli_tvSource);
        ivHeadline = itemView.findViewById(R.id.hli_ivHeadline);
        cvMain = itemView.findViewById(R.id.hli_cvMain);
    }
}
