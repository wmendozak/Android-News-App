package com.example.assignment02;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import com.example.assignment02.Models.Headline;
import com.example.assignment02.Models.NewsApiResponse;

import java.util.List;

public class NewsHeadlinesActivity extends AppCompatActivity implements SelectListener  {
    RecyclerView recyclerView;
    CustomAdapter adapter;
    ProgressDialog dialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_news_headlines);

        dialog = new ProgressDialog(this);
        dialog.setTitle("Fetching news articles");
        dialog.show();

        Intent intent = getIntent();
        String country = intent.getStringExtra("country");
        String category = intent.getStringExtra("category");
        //Toast.makeText(NewsHeadlinesActivity.this,country + " --- " + category, Toast.LENGTH_SHORT).show();
        this.setTitle(" > " + country + " > " + category);
        RequestManager manager = new RequestManager(this);
        manager.getNewsHeadlines(listener, country, category);
    }

    private final OnFetchDataListener<NewsApiResponse> listener = new OnFetchDataListener<NewsApiResponse>() {
        @Override
        public void onFetchData(List<Headline> list, String message) {
            showNews(list);
            dialog.dismiss();
        }

        @Override
        public void onError(String message) {

        }
    };

    private void showNews(List<Headline> list) {
        recyclerView = findViewById(R.id.nha_recycler_main);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new GridLayoutManager(this, 1));
        adapter = new CustomAdapter(this, list, this);
        recyclerView.setAdapter(adapter);
    }

    @Override
    public void OnNewsClicked(Headline headline) {
        startActivity(new Intent(NewsHeadlinesActivity.this, DetailsActivity.class).putExtra("data", headline));
    }
}