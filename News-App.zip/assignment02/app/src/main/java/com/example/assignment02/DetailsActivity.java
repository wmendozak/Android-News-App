package com.example.assignment02;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.assignment02.Models.Headline;
import com.squareup.picasso.Picasso;

public class DetailsActivity extends AppCompatActivity {
    Headline headline;
    TextView tvTitle, tvDescription, tvPublishedAt, tvUrl;
    ImageView ivHeadline;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);

        tvTitle = findViewById(R.id.da_tvTitle);
        tvDescription = findViewById(R.id.da_tvDescription);
        tvPublishedAt = findViewById(R.id.da_tvPublishedAt);
        tvUrl = findViewById(R.id.da_tvUrl);
        ivHeadline = findViewById(R.id.da_ivHeadline);

        headline = (Headline) getIntent().getSerializableExtra("data");

        this.setTitle(" > " + headline.getSource().getName());
        tvTitle.setText(headline.getTitle());
        tvDescription.setText(headline.getDescription());
        tvPublishedAt.setText(headline.getPublishedAt());
        tvUrl.setText(headline.getUrl());
        Picasso.get().load(headline.getUrlToImage()).into(ivHeadline);

        tvUrl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Toast.makeText( DetailsActivity.this, "Clicked", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(DetailsActivity.this, BrowserActivity.class).putExtra("url", headline.getUrl()));
            }
        });
    }


}