package com.example.assignment02;

import com.example.assignment02.Models.Headline;

import java.util.List;

public interface OnFetchDataListener<NewsApiResponse> {
    void onFetchData(List<Headline> list, String message);
    void onError(String message);
}
