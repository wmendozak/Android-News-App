package com.example.assignment02;

import com.example.assignment02.Models.Headline;

public interface SelectListener {
    void OnNewsClicked(Headline headline);
}
